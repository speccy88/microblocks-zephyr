import fcntl,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path(__file__).resolve().parents[1];out=root/'build-artifacts/zephyr-full-profile-public-review';old=json.loads((out/'receipt.json').read_text());build=pathlib.Path(old['build']);assert old['build_timeout'] and old['build_returncode']==-15 and not old['compiled']
assert str(build).startswith('/tmp/p4-zephyr-review-') and build.name=='build' and (build/'build.ninja').is_file()
cache=(build/'CMakeCache.txt').read_text();assert str(root/'build-artifacts/p4-full-profile-public-inputs/gp-assets') in cache
assert 'P4_WHISTLE_FIXTURE' not in cache
for name,record in old['outputs'].items():assert hashlib.sha256((build/'zephyr'/name).read_bytes()).hexdigest()==record['sha256']
with (build/'.owned-resume.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 report={'prior_returncode':old['build_returncode'],'prior_timeout':True,'command':['cmake','--build',str(build),'--','-j2'],'scope':old['scope'],'hardware_touched':False,'private_audio_used':False,'build':str(build)};start=time.monotonic()
 env=dict(os.environ,PATH='/home/fred/microblocks-zephyr-work/.venv/bin'+os.pathsep+os.environ['PATH'])
 p=subprocess.Popen(report['command'],cwd=build,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 print(json.dumps({'phase':'resuming known-stopped isolated build','build':str(build),'pid':p.pid}),flush=True)
 try:log,_=p.communicate(timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);log,_=p.communicate(timeout=15);report['timeout']=True
 (out/'resume-build.txt').write_text(log);report.update(returncode=p.returncode,compiled=p.returncode==0,seconds=time.monotonic()-start,log_tail=log[-4000:])
 for name in ('zephyr.elf','zephyr.bin','.config','zephyr.dts'):
  path=build/'zephyr'/name
  if path.is_file():
   raw=path.read_bytes();(out/name).write_bytes(raw);report.setdefault('outputs',{})[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 (out/'resume-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(p.returncode)
