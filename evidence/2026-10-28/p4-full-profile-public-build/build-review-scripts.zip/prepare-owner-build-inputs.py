"""Recover only licensed, pinned public inputs; no protected checkout/audio/keys."""
import hashlib,json,pathlib,shutil,subprocess,sys,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1];out=ROOT/'build-artifacts/p4-full-profile-public-inputs';out.mkdir(exist_ok=True)
def verified(raw,size,digest):
    assert len(raw)==size and hashlib.sha256(raw).hexdigest()==digest
    return raw
w=json.loads((ROOT/'dependencies/p4-whistle.json').read_text())
model=pathlib.Path('C:/Users/fred_/Documents/Codex/whistle_esp32_s3_rlcd_v0.1.0/whistle-esp32/release/whistle_d4.cact')
raw=verified(model.read_bytes(),w['model']['bytes'],w['model']['sha256']);(out/'whistle_d4.cact').write_bytes(raw)
subprocess.run([sys.executable,str(ROOT/'tools/fetch_p4_whistle_sources.py'),'--output',str(out/'whistle-sources')],check=True,timeout=180)
k=json.loads((ROOT/'dependencies/p4-wake-word.json').read_text());url='https://raw.githubusercontent.com/'+k['source']+'/'+k['source_commit']+'/'+k['path']
raw=urllib.request.urlopen(url,timeout=30).read();(out/'okay_nabu.tflite').write_bytes(verified(raw,k['model_bytes'],k['model_sha256']))
licurl='https://raw.githubusercontent.com/'+k['source']+'/'+k['source_commit']+'/LICENSE';lic=urllib.request.urlopen(licurl,timeout=30).read();(out/'okay-nabu-LICENSE').write_bytes(lic)
sys.path.insert(0,str(ROOT/'tools'));from package_p4_hosted import package
assets=package(ROOT.parent/'microblocks-zephyr-integration-20261027/build-artifacts/ide-source',out/'gp-assets',ROOT)
report={'scope':'Build inputs only; not owner image reproduction or flashed firmware','whistle_model':{'bytes':len((out/'whistle_d4.cact').read_bytes()),'sha256':w['model']['sha256'],'source':'existing licensed release outside protected P4 checkout, exact repository pin'},'kws':{'source_url':url,'sha256':k['model_sha256'],'bytes':k['model_bytes'],'license_sha256':hashlib.sha256(lic).hexdigest()},'hosted_assets':assets,'private_audio_used':False,'credentials_used':False,'protected_checkout_accessed':False,'exact_owner_rebuild_blockers':['Retained private camera-ready.wav fixture not accessed or substituted','Owner exact hosted asset blob differs from freshly regenerated current GP assets','Owner SDK reports1.0.1; available reviewed compiler is SDK1.0.0 GNU14.3.0'],'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.rglob('*') if p.is_file()}}
(out/'inputs.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='files'}))
