import pathlib
root=pathlib.Path(__file__).resolve().parents[1];p=root/'build-artifacts/run-full-profile-public-review.py';s=p.read_text()
before="base=pathlib.Path(tempfile.mkdtemp(prefix='p4-zephyr-review-',dir='/tmp'));ws=base/'workspace'"
after="base=pathlib.Path(tempfile.mkdtemp(prefix='microblocks-js-p4-build-',dir='/home/fred'));(base/'.owned-public-input-build').write_text(str(base)+'\\n');ws=base/'workspace'"
assert s.count(before)==1;s=s.replace(before,after).replace('zephyr-full-profile-public-review','zephyr-full-profile-persistent-review').replace('process.communicate(timeout=600)','process.communicate(timeout=1200)')
(root/'build-artifacts/run-persistent-full-profile-review.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared persistent dedicated Linux build; same exact source/profile inputs; no flash or private audio')
