import pathlib
root=pathlib.Path(__file__).resolve().parents[1]
source=(root/'build-artifacts/run-isolated-zephyr-review-fixed.py').read_text()
replacements={
"zephyr-isolated-review-fixed":"zephyr-full-profile-public-review",
"9c60ae6f77ba48d0b55bd33fd34b63cff8fcb49e plus optional SD diagnostic guard; frozen validation inputs p4-sd-stack-final":"9ba2f25b898c827a2ad7939758492818dfce15c2; P4 source unchanged; public-input full-profile review",
"fresh minimal camera/audio/SD source configuration; neural/Whistle/KWS/private media omitted; never an exact owner image rebuild":"station/neural/Whistle/KWS/SD/saved-boot full-profile source build with newly generated GP assets; private audio fixture omitted; SDK1.0.0; never an exact owner image rebuild",
"env=dict(os.environ,ZEPHYR_BASE=str(z),PATH=":"env=dict(os.environ,ZEPHYR_SDK_INSTALL_DIR=str(art/'zephyr-sdk-1.0.0-review'),ZEPHYR_BASE=str(z),PATH=",
"'-DEXTRA_CONF_FILE=profiles/sd-files.conf','-DEXTRA_DTC_OVERLAY_FILE=profiles/sd-readonly.overlay'":"'-DEXTRA_CONF_FILE=profiles/station.conf;profiles/neural.conf;profiles/whistle.conf;profiles/compat-diagnostic.conf;profiles/sd-files.conf;profiles/saved-boot.conf;profiles/wifi-loss-retry.conf;profiles/wifi-latency-diagnostic.conf;profiles/wifi-low-latency.conf','-DEXTRA_DTC_OVERLAY_FILE=profiles/c6-sdio.overlay;profiles/hosted.overlay;profiles/sd-readonly.overlay','-DP4_HOSTED_ASSETS_DIR='+str(art/'p4-full-profile-public-inputs/gp-assets'),'-DP4_WHISTLE_SOURCES='+str(art/'p4-full-profile-public-inputs/whistle-sources'),'-DP4_WHISTLE_MODEL='+str(art/'p4-full-profile-public-inputs/whistle_d4.cact'),'-DP4_KWS_MODEL='+str(art/'p4-full-profile-public-inputs/okay_nabu.tflite'),'-DP4_TFLM_SOURCE='+str(sdk/'optional/modules/lib/tflite-micro'),'-DZEPHYR_EXTRA_MODULES='+str(sdk/'optional/modules/lib/tflite-micro')",
"building minimal isolated P4 camera/audio/SD image":"building isolated P4 full profile with public inputs; no private audio",
"process.communicate(timeout=300)":"process.communicate(timeout=600)"
}
for before,after in replacements.items():
    assert source.count(before)==1,(before,source.count(before));source=source.replace(before,after)
(root/'build-artifacts/run-full-profile-public-review.py').write_text(source,encoding='utf-8',newline='\n')
print('Prepared isolated full-profile source review; private fixture omitted; no hardware commands')
