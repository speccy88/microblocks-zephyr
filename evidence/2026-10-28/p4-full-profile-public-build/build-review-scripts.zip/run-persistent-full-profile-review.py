import hashlib,json,os,pathlib,subprocess,sys,tempfile,time,signal
root=pathlib.Path(__file__).resolve().parents[1];art=root/'build-artifacts';sdk=pathlib.Path('/home/fred/microblocks-zephyr-work');out=art/'zephyr-full-profile-persistent-review';out.mkdir(exist_ok=True)
base=pathlib.Path(tempfile.mkdtemp(prefix='microblocks-js-p4-build-',dir='/home/fred'));(base/'.owned-public-input-build').write_text(str(base)+'\n');ws=base/'workspace';ws.mkdir();z=ws/'zephyr';start=time.monotonic();commands=[]
def run(args,cwd=None,timeout=120):
 commands.append(args);p=subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=timeout);return p
report={'workspace':str(ws),'source_revision':'9ba2f25b898c827a2ad7939758492818dfce15c2; P4 source unchanged; public-input full-profile review','original_sdk':str(sdk),'original_sdk_changed':False,'hardware_touched':False,'scope':'station/neural/Whistle/KWS/SD/saved-boot full-profile source build with newly generated GP assets; private audio fixture omitted; SDK1.0.0; never an exact owner image rebuild'}
try:
 p=run(['git','clone','--shared','--no-checkout',str(sdk/'zephyr'),str(z)]);assert p.returncode==0,p.stderr
 p=run(['git','-C',str(z),'checkout','--detach','a915b2f12675b48b16d56653ea145dcd8f20cbbf']);assert p.returncode==0,p.stderr
 (ws/'.west').mkdir();(ws/'.west/config').write_text('[manifest]\npath = zephyr\n')
 for name in ('modules','tools','bootloader'):
  if (sdk/name).is_dir():(ws/name).symlink_to(sdk/name,target_is_directory=True)
 # Clone checkout is owned here; apply only the reviewed exact pinned series.
 p=run([sys.executable,str(root/'tools/apply_p4_zephyr_patches.py'),'--zephyr',str(z),'--execute']);(out/'patches.txt').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
 source=base/'smallvm';source.mkdir();lock=json.loads((root/'dependencies/smallvm-v417.json').read_text())
 for item in lock['files']:
  raw=subprocess.check_output(['git','-C',str(root.parent/'smallvm-linux-upstream'),'show',lock['canonical_commit']+':'+item['path']]);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  target=source/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 (source/'provenance.json').write_text(json.dumps(lock));(source/'LICENSE').write_bytes(subprocess.check_output(['git','-C',str(root.parent/'smallvm-linux-upstream'),'show',lock['canonical_commit']+':LICENSE']))
 env=dict(os.environ,ZEPHYR_SDK_INSTALL_DIR=str(art/'zephyr-sdk-1.0.0-review'),ZEPHYR_BASE=str(z),PATH=str(sdk/'.venv/bin')+os.pathsep+os.environ['PATH']);command=[str(sdk/'.venv/bin/west'),'build','--cmake-only','-b','esp32p4_wifi6/esp32p4/hpcore','-s',str(root/'boards/waveshare_esp32p4_wifi6/zephyr'),'-d',str(base/'build'),'--','-DSMALLVM_SOURCE_DIR='+str(source),'-DEXTRA_CONF_FILE=profiles/station.conf;profiles/neural.conf;profiles/whistle.conf;profiles/compat-diagnostic.conf;profiles/sd-files.conf;profiles/saved-boot.conf;profiles/wifi-loss-retry.conf;profiles/wifi-latency-diagnostic.conf;profiles/wifi-low-latency.conf','-DEXTRA_DTC_OVERLAY_FILE=profiles/c6-sdio.overlay;profiles/hosted.overlay;profiles/sd-readonly.overlay','-DP4_HOSTED_ASSETS_DIR='+str(art/'p4-full-profile-public-inputs/gp-assets'),'-DP4_WHISTLE_SOURCES='+str(art/'p4-full-profile-public-inputs/whistle-sources'),'-DP4_WHISTLE_MODEL='+str(art/'p4-full-profile-public-inputs/whistle_d4.cact'),'-DP4_KWS_MODEL='+str(art/'p4-full-profile-public-inputs/okay_nabu.tflite'),'-DP4_TFLM_SOURCE='+str(sdk/'optional/modules/lib/tflite-micro'),'-DZEPHYR_EXTRA_MODULES='+str(sdk/'optional/modules/lib/tflite-micro')]
 commands.append(command);p=subprocess.run(command,cwd=ws,env=env,capture_output=True,text=True,timeout=120);(out/'configure.txt').write_text(p.stdout+p.stderr)
 report.update(configure_returncode=p.returncode,configured=p.returncode==0,compiled=False,build=str(base/'build'),zephyr=str(z),log_tail=(p.stdout+p.stderr)[-3500:])
 if p.returncode==0:
  command=['cmake','--build',str(base/'build'),'--','-j2'];commands.append(command)
  print(json.dumps({'phase':'building isolated P4 full profile with public inputs; no private audio','build':str(base/'build'),'hardware':False}),flush=True)
  process=subprocess.Popen(command,cwd=ws,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
  try:log,_=process.communicate(timeout=1200)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGTERM)
   try:log,_=process.communicate(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);log,_=process.communicate()
   report['build_timeout']=True
  (out/'build.txt').write_text(log)
  report.update(build_returncode=process.returncode,compiled=process.returncode==0,log_tail=log[-3500:])
  for name in ('zephyr.elf','zephyr.bin','.config','zephyr.dts'):
   source=base/'build/zephyr'/name
   if source.is_file():
    data=source.read_bytes();(out/name).write_bytes(data)
    report.setdefault('outputs',{})[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

except Exception as e:report.update(configured=False,compiled=False,error=str(e))
report.update(seconds=time.monotonic()-start,commands=commands)
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
