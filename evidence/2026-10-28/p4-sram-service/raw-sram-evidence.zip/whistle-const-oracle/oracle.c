
#include <stdio.h>
#include WHISTLE_SOURCE
int main(int argc, char **argv) {
    if (argc != 4) return 90;
    FILE *f = fopen(argv[1], "rb"); if (!f) return 91;
    fseek(f, 0, SEEK_END); long size = ftell(f); rewind(f);
    unsigned char *blob = malloc(size); if (!blob) return 92;
    if (fread(blob, 1, size, f) != (size_t)size) return 93; fclose(f);
    if (atoi(argv[3])) {
        nd_cact c; nd_tensor t;
        if (nd_cact_open(&c, blob, size) || nd_cact_tensor(&c, 10 + c.h4.num_layers * 27, &t)) return 94;
        /* Change one valid integer, leaving metadata untouched. */
        if (t.dtype == ND_DT_FP16) {
            uint16_t old; memcpy(&old, blob+t.offset, 2);
            uint16_t other = old == 0 ? 0x3c00 : 0;
            memcpy(blob+t.offset, &other, 2);
        } else if (t.dtype == ND_DT_FP32) {
            float old; memcpy(&old, blob+t.offset, 4);
            float other = old == 0 ? 1.0f : 0.0f;
            memcpy(blob+t.offset, &other, 4);
        } else return 95;
    }
    nd_whistle w; int rc = nd_whistle_open(&w, blob, size);
    if (atoi(argv[3])) { nd_whistle_close(&w); free(blob); return rc == -13 ? 0 : 96; }
    if (rc) return 97;
    f = fopen(argv[2], "wb"); if (!f) return 98;
    fwrite(s_perm1, sizeof(s_perm1), 1, f); fwrite(s_perm2, sizeof(s_perm2), 1, f);
    float pcm[1600]; for (int i=0; i<1600; ++i) pcm[i] = (float)((i*17)%101-50) / 100.0f;
    size_t count = (size_t)nd_whistle_frames(&w, 1600) * w.d;
    float *out = calloc(count, sizeof(float)); if (!out) return 99;
    if (nd_whistle_encode(&w, pcm, 1600, out)) return 100;
    for (size_t i=0; i<count; ++i) if (!isfinite(out[i])) return 101;
    fwrite(out, sizeof(float), count, f); fclose(f);
    free(out); nd_whistle_close(&w); free(blob); return 0;
}
