import hashlib,importlib.util,json,pathlib,shutil,subprocess,sys,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'build-artifacts/pi-model-gui-20261028'
if OUT.exists():raise SystemExit('Refusing existing acceptance kit')
OUT.mkdir()
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'linux/arm64')]
import build,package_js_editor
build.prepare(ROOT.parent/'smallvm-linux-upstream',OUT/'native-build',False)
for name in ('session.py','bridge.py'):
    p=OUT/'linux/arm64'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'linux/arm64'/name,p)
for p in (ROOT/'linux/microduck').glob('*'):
    if p.is_file() and p.suffix in ('.py','.ubl'):
        target=OUT/'linux/microduck'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for name in ('test_linux_microduck_vm.py','linux_arm64_protocol.py','test_linux_microduck_robot_service.py','test_linux_microduck_robot_model.py'):
    p=OUT/'tests'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'tests'/name,p)
arithmetic="module main\nauthor unknown\nversion 1 0\ndescription 'Private real Pi acceptance; no hardware IO.'\nscript 40 60 (20 + 22)\n"
for profile,name in [('raspberry-pi5','editor-pi'),('development','editor-dev')]:
    package_js_editor.package(ROOT.parent/'microblocks-editor-upstream-20261027',OUT/name,profile=profile)
    d=OUT/name
    (d/'Acceptance').mkdir();(d/'Acceptance/PiArithmetic.ubp').write_text(arithmetic,encoding='utf-8',newline='\n')
    if profile=='development':
        project=arithmetic+"\nscript 40 130 (microduckEasyValue (microduckEasyMissingServos))\nscript 40 200 (microduckEasyValue (microduckEasyModelName))\nscript 40 270 {\n local 'snapshot' (microduckRobotModelCapture)\n local 'reading' (microduckRobotModelTrunkHeight snapshot)\n microduckRobotModelRelease snapshot\n return (microduckEasyValue reading)\n}\n"
        project+=(d/'Libraries/MicroDuck Starter Lab.ubl').read_text(encoding='utf-8')
        (d/'Acceptance/PiModel.ubp').write_text(project,encoding='utf-8',newline='\n')
    shutil.copyfile(ROOT/'build-artifacts/pi-model-gui-lab.js',d/'acceptance-lab.js')
    html=(d/'microblocks.html').read_text(encoding='utf-8');assert '</body>' in html
    (d/'microblocks.html').write_text(html.replace('</body>','<script src="acceptance-lab.js"></script>\n</body>'),encoding='utf-8',newline='\n')
    # These are separate lab additions; original package hashes remain available.
    with (d/'files.txt').open('a',encoding='utf-8',newline='\n') as f:
        f.write('Acceptance/PiArithmetic.ubp\n')
        if profile=='development':f.write('Acceptance/PiModel.ubp\n')
        f.write('acceptance-lab.js\n')
shutil.copyfile(ROOT/'build-artifacts/pi-model-gui-supervisor.py',OUT/'gui-supervisor.py')
manifest={'checkpoint':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'physical_robot':False,'simulation':'Protocol-shaped robotd fixture only','files':{p.relative_to(OUT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.rglob('*')) if p.is_file()}}
(OUT/'kit-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
archive=OUT.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():tar.add(p,arcname=p.relative_to(OUT),recursive=False)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest['files'])}))
