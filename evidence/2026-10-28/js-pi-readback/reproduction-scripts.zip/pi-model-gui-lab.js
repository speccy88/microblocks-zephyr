// Test-only controls added to a private package. Not a production editor patch.
// Real Pi VM; the robotd source is explicitly fictional and read-only.
window.addEventListener('load', () => {
  const section=document.createElement('section');section.id='pi-acceptance';
  section.style.cssText='position:fixed;right:8px;top:84px;width:340px;z-index:99998;background:#fff6d8;color:#111;padding:10px;border:2px solid #725200;font:13px sans-serif';
  const title=document.createElement('strong');title.textContent='PRIVATE ACCEPTANCE LAB — real Pi, fictional robot';section.append(title);
  const output=document.createElement('pre');output.id='acceptance-report';output.style.cssText='white-space:pre-wrap;max-height:340px;overflow:auto;font:12px monospace';
  const report={simulation:true,physical_robot:false,results:[],events:[],errors:[]};window.piAcceptance=report;
  const update=()=>{report.connected=MB_connection.isConnected();report.vm=MB_connection.vmVersion;report.board=MB_connection.boardType;report.modules=MB_editor.project.libraries.size;report.functions=MB_editor.project.allFunctions().length;report.scripts=MB_editor.project.main.scripts.length;output.textContent=JSON.stringify(report,null,2);};
  const result=MB_editor.showResult;MB_editor.showResult=function(id,value,error){report.results.push({id,value,error:!!error});if(report.results.length>30)report.results.shift();result.call(this,id,value,error);update();};
  const add=(text,fn)=>{const b=document.createElement('button');b.textContent=text;b.onclick=async()=>{try{await fn();report.events.push(text);}catch(e){report.errors.push(String(e));}update();};section.append(b);};
  add('Open Pi arithmetic fixture',async()=>{await MB_Files.initialize();await MB_editor.openProjectFromFile('Acceptance/PiArithmetic.ubp');});
  if(MicroBlocksJSProfile.id==='development')add('Open coexisting simple + advanced fixture',async()=>{await MB_Files.initialize();await MB_editor.openProjectFromFile('Acceptance/PiModel.ubp');});
  add('Serialize and reopen current project',async()=>{MB_editor.endOpenEdit();MB_editor.updateProject();const text=MB_editor.project.codeString();report.roundtrip={bytes:new TextEncoder().encode(text).length,scripts:MB_editor.project.main.scripts.length,functions:MB_editor.project.allFunctions().length};MB_editor.unsavedEdits=false;await MB_editor.openProjectFromString(text,'PiAcceptanceRoundtrip.ubp');});
  add('Read current Pi program',async()=>{await MB_editor.openProjectFromBoard();});
  add('Refresh test status',async()=>{});section.append(output);document.body.append(section);update();
});
