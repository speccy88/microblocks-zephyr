const fs=require('node:fs'),path=require('node:path'),{load}=require('../tests/support/js_editor_headless.cjs');
(async()=>{
const assets=path.join(__dirname,'pi-model-gui-20261028/editor-dev'),h=load(assets);
h.set('sourceText',fs.readFileSync(path.join(assets,'Acceptance/PiModel.ubp'),'utf8'));
h.evaluate('MB_editor.project=new MB_Project();MB_editor.project.loadFromString(sourceText);MB_editor.codeManager=new MB_CodeManager(MB_editor.project);');
h.evaluate('MB_editor.codeManager.assignFunctionIDs();globalThis.compiler=new MB_Compiler(MB_editor.project,MB_editor.codeManager);');
const functions=h.evaluate('MB_editor.project.allFunctions().filter(f=>!MB_editor.project.unusedFunctions().includes(f.functionName)).map(f=>({name:f.functionName,id:MB_editor.codeManager.functionChunkIDs.get(f.functionName),kind:3,bytes:compiler.compiledBytesFor(f)}))');
const scripts=h.evaluate('MB_editor.project.main.scripts.map((s,i)=>({id:211+i,kind:s[2].isReporter?2:1,bytes:compiler.compiledBytesFor(s[2])}))');
h.set('originals',functions);h.set('chunks',[...functions,...scripts]);h.evaluate('globalThis.d=new MB_Decompiler();for(const c of [...chunks].reverse()){const bytes=[...c.bytes];while(bytes.length%4)bytes.push(0);d.addChunk(c.id,c.kind,new Uint8Array(bytes));}');
const project=await h.evaluate('d.decompileProject()');h.set('restored',project);
fs.writeFileSync(path.join(__dirname,'microduck-readback-restored.ubp'),h.evaluate('restored.codeString()'));
h.evaluate('globalThis.manager=new MB_CodeManager(restored);for(const c of originals)manager.functionChunkIDs.set(c.name,c.id);globalThis.recompiler=new MB_Compiler(restored,manager)');
const after=h.evaluate('originals.map(c=>({name:c.name,bytes:recompiler.compiledBytesFor(restored.functionNamed(c.name))}))');
const bad=after.filter(c=>JSON.stringify(c.bytes)!==JSON.stringify(functions.find(f=>f.name===c.name).bytes));
fs.writeFileSync(path.join(__dirname,'microduck-readback-byte-diff.json'),JSON.stringify({count:functions.length,bad:bad.map(c=>({name:c.name,before:functions.find(f=>f.name===c.name).bytes,after:c.bytes}))},null,2));
console.log(JSON.stringify({functions:functions.length,nonidentical:bad.map(c=>c.name)}));
})().catch(e=>{console.error(e);process.exitCode=1});
