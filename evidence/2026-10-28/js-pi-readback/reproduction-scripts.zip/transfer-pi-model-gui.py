import hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];art=ROOT/'build-artifacts';archive=art/'pi-model-gui-20261028.tar.gz'
ssh=['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','rpi5']
def remote(code,timeout=60):return subprocess.run([*ssh,'python3 -'],input=code.encode(),capture_output=True,timeout=timeout,check=True).stdout.decode()
root=remote("import os,tempfile,json,pathlib;os.umask(0o077);r=pathlib.Path(tempfile.mkdtemp(prefix='microblocks-model-gui-',dir='/home/fred'));(r/'.owned-model-gui').write_text(str(r)+'\\n');print(json.dumps({'root':str(r)}))")
target=json.loads(root)['root'];assert target.startswith('/home/fred/microblocks-model-gui-')
receipt={'root':target,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'checkpoint':'9ba2f25b898c827a2ad7939758492818dfce15c2'}
(art/'pi-model-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['scp','-q','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',str(archive),'rpi5:'+target+'/kit.tar.gz'],check=True,timeout=60)
code=f'''import hashlib,json,os,pathlib,subprocess,tarfile,time
r=pathlib.Path({target!r});os.umask(0o077)
assert (r/'.owned-model-gui').read_text().strip()==str(r)
assert hashlib.sha256((r/'kit.tar.gz').read_bytes()).hexdigest()=={receipt['archive_sha256']!r}
with tarfile.open(r/'kit.tar.gz','r:gz') as tar:
 for m in tar.getmembers():
  assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
 tar.extractall(r,filter='data')
manifest=json.loads((r/'kit-manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
start=time.monotonic();p=subprocess.run(['sh',str(r/'native-build/build.sh')],capture_output=True,text=True,timeout=120);(r/'build.stdout').write_text(p.stdout);(r/'build.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr[-2000:]
p=subprocess.run([str(r/'native-build/smallvm'),'--self-test'],capture_output=True,text=True,timeout=30);(r/'self-test.txt').write_text(p.stdout+p.stderr);assert p.returncode==0
binary=r/'native-build/smallvm';report={{'root':str(r),'architecture':os.uname().machine,'vm_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'self_test':p.stdout.strip(),'source_commit':manifest['checkpoint'],'build_seconds':time.monotonic()-start}}
env=dict(os.environ,SMALLVM_MICRODUCK_BINARY=str(binary));p=subprocess.run(['python3','-m','unittest','discover','-s','tests','-p','test_linux_microduck_robot_model.py','-v'],cwd=r,env=env,capture_output=True,text=True,timeout=90);(r/'model-tests.stdout').write_text(p.stdout);(r/'model-tests.stderr').write_text(p.stderr);report.update(model_tests_returncode=p.returncode,model_tests=p.stderr[-1500:]);(r/'pi-build-receipt.json').write_text(json.dumps(report,indent=2)+'\\n');print(json.dumps(report));assert p.returncode==0
'''
try:
    result=remote(code,timeout=240);(art/'pi-model-build-result.json').write_text(result);print(result)
except subprocess.CalledProcessError as e:
    (art/'pi-model-build-failure.txt').write_bytes(e.stdout+b'\n'+e.stderr);print(e.stdout.decode());print(e.stderr.decode());raise
