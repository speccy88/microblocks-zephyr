import json,pathlib,shutil,subprocess
root=pathlib.Path(__file__).resolve().parents[1];base=root/'build-artifacts/readback-baseline-negative'
base.mkdir();(base/'tests/support').mkdir(parents=True);(base/'web').mkdir()
shutil.copytree(root/'web/js-editor',base/'web/js-editor')
for name in ('js-readback.test.cjs','support/js_editor_headless.cjs'):shutil.copyfile(root/'tests'/name,base/'tests'/name)
old=subprocess.check_output(['git','show','9ba2f25b898c827a2ad7939758492818dfce15c2:web/js-editor/readback-compat.js'],cwd=root)
(base/'web/js-editor/readback-compat.js').write_bytes(old)
node='C:/Users/fred_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
p=subprocess.run([node,str(base/'tests/js-readback.test.cjs'),str(root/'build-artifacts/pi-model-gui-20261028/editor-dev')],capture_output=True,text=True,timeout=30)
report={'baseline':'9ba2f25b898c827a2ad7939758492818dfce15c2','returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'expected_negative':p.returncode!=0 and '3 !== 1' in p.stderr}
(root/'build-artifacts/readback-negative-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert report['expected_negative']
