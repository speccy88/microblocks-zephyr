import json,os,pathlib,platform,subprocess
rows=[]
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        exe=os.readlink(p/'exe')
        if pathlib.Path(exe).name=='smallvm':rows.append({'pid':int(p.name),'exe':exe,'start':(p/'stat').read_text().split()[21]})
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
python='/home/fred/microblocks-charlie/bridge-venv/bin/python'
print(json.dumps({'hostname':platform.node(),'architecture':platform.machine(),'user':os.geteuid(),'vms':rows,'bridge_python':pathlib.Path(python).exists(),'websockets':subprocess.check_output([python,'-c','import websockets;print(websockets.__version__)'],text=True).strip()}))
