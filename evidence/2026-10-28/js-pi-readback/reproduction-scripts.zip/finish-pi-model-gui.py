import json,pathlib,subprocess
art=pathlib.Path(__file__).resolve().parent;root=json.loads((art/'pi-model-transfer.json').read_text())['root']
code=f'''import hashlib,json,os,pathlib,time,zipfile
r=pathlib.Path({root!r});assert (r/'.owned-model-gui').read_text().strip()==str(r)
for profile in ('pi','dev'):
 d=r/('gui-'+profile);status=json.loads((d/'watchdog.json').read_text());assert status['root']==str(r) and status['profile']==profile
 (d/'stop').write_text('Acceptance complete; stop only owned children.\\n')
until=time.monotonic()+20
while not all((r/('gui-'+p)/'ended.json').exists() for p in ('pi','dev')):
 assert time.monotonic()<until,'Owned watchdog cleanup deadline';time.sleep(.2)
ended={{p:json.loads((r/('gui-'+p)/'ended.json').read_text()) for p in ('pi','dev')}}
assert all(e['owned_children_stopped'] and e['supervisor_returncode']==0 for e in ended.values()),ended
rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=os.readlink(p/'exe')
  if pathlib.Path(exe).name=='smallvm':rows.append({{'pid':int(p.name),'exe':exe,'start':(p/'stat').read_text().split()[21]}})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
audit=json.loads((r/'gui-dev/fictional-robot-audit.json').read_text());assert all(q['method'] in ('hello','robot.health','robot.model','robot.subscribe') for q in audit)
files=['kit-manifest.json','native-build/source-manifest.json','pi-build-receipt.json','build.stdout','build.stderr','self-test.txt','model-tests.stdout','model-tests.stderr']
for profile in ('pi','dev'):
 d=r/('gui-'+profile)
 for name in ('watchdog.json','ended.json','supervisor.log','fictional-robot-audit.json'):
  if (d/name).is_file():files.append(str((d/name).relative_to(r)))
 for p in (d/'program').iterdir():
  if p.name=='session.json' or p.name.endswith('.log'):files.append(str(p.relative_to(r)))
with zipfile.ZipFile(r/'acceptance-evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name in files:z.write(r/name,name)
report={{'root':str(r),'ended':ended,'existing_vms_after':rows,'robot_methods':sorted(set(q['method'] for q in audit)),'robot_audit_requests':len(audit),'credentials_used_or_recorded':False,'hardware_commands':False,'archive_sha256':hashlib.sha256((r/'acceptance-evidence.zip').read_bytes()).hexdigest(),'adapter_sha256':hashlib.sha256((r/'editor-dev/readback-compat.js').read_bytes()).hexdigest()}}
(r/'cleanup-receipt.json').write_text(json.dumps(report,indent=2)+'\\n');print(json.dumps(report))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5','python3 -'],input=code.encode(),capture_output=True,timeout=35);print(p.stdout.decode());print(p.stderr.decode());p.check_returncode()
report=json.loads(p.stdout);before=json.loads((art/'pi-model-before.json').read_text())['vms'];assert report['existing_vms_after']==before
report['preexisting_vms_preserved_exactly']=True;(art/'pi-model-cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['scp','-q','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5:'+root+'/acceptance-evidence.zip',str(art/'pi-model-acceptance-evidence.zip')],check=True,timeout=45)
import hashlib
assert hashlib.sha256((art/'pi-model-acceptance-evidence.zip').read_bytes()).hexdigest()==report['archive_sha256']
