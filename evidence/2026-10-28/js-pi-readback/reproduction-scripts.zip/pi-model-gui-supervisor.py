"""Private bounded graphical lab. Real Pi, source-shaped fictional robotd only."""
import argparse,asyncio,hashlib,json,os,pathlib,signal,socket,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))
import test_linux_microduck_robot_model as model

async def main():
    ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['pi','dev'],required=True);ap.add_argument('--port',type=int,required=True);args=ap.parse_args()
    os.umask(0o077);run=ROOT/('gui-'+args.profile);run.mkdir(mode=0o700)
    stop=asyncio.Event();loop=asyncio.get_running_loop()
    for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):loop.add_signal_handler(sig,stop.set)
    wire=gateway=None;child=None;report={'profile':args.profile,'port':args.port,'architecture':os.uname().machine,'real_pi':True,'robot_source':'fictional','physical_robot':False,'max_seconds':1800,'root':str(ROOT),'watchdog_pid':os.getpid()}
    try:
        extra=[]
        if args.profile=='dev':
            wire=await model.helper.RobotWire(run/'fictional-robot.sock').start();wire.model=model.fixture()
            gateway=await model.helper.normal_gateway(run/'gateway',wire.path)
            extra=['--microduck-socket',str(run/'gateway/gateway.sock')]
        with (run/'supervisor.log').open('x') as log:
            child=subprocess.Popen([sys.executable,str(ROOT/'linux/arm64/session.py'),'--binary',str(ROOT/'native-build/smallvm'),'--editor',str(ROOT/('editor-'+args.profile)),'--data',str(run/'program'),'--port',str(args.port),*extra],stdout=log,stderr=subprocess.STDOUT)
            report['supervisor_pid']=child.pid;(run/'watchdog.json').write_text(json.dumps(report,indent=2)+'\n')
            until=time.monotonic()+1800
            while not stop.is_set() and not (run/'stop').exists() and child.poll() is None and time.monotonic()<until:await asyncio.sleep(.2)
            if child.poll() is None:
                child.terminate()
                try:await asyncio.to_thread(child.wait,15)
                except subprocess.TimeoutExpired:child.kill();await asyncio.to_thread(child.wait,5)
            report['supervisor_returncode']=child.returncode
    finally:
        if child and child.poll() is None:
            child.terminate();await asyncio.to_thread(child.wait,15)
        if gateway:await gateway.stop()
        if wire:
            (run/'fictional-robot-audit.json').write_text(json.dumps(wire.audit,indent=2)+'\n');await wire.stop()
        report['owned_children_stopped']=child is None or child.poll() is not None
        (run/'ended.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':asyncio.run(main())
