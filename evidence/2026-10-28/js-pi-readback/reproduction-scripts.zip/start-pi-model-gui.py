import json,pathlib,subprocess,sys
art=pathlib.Path(__file__).resolve().parent;r=json.loads((art/'pi-model-transfer.json').read_text())['root'];profile=sys.argv[1];port=int(sys.argv[2]);assert profile in ('pi','dev')
code=f'''import json,os,pathlib,socket,subprocess,time
r=pathlib.Path({r!r});os.umask(0o077);profile={profile!r};port={port};assert (r/'.owned-model-gui').read_text().strip()==str(r)
with socket.socket() as probe:probe.bind(('127.0.0.1',port))
with (r/('watchdog-'+profile+'.stdout')).open('x') as out,(r/('watchdog-'+profile+'.stderr')).open('x') as err:
 p=subprocess.Popen(['/home/fred/microblocks-charlie/bridge-venv/bin/python',str(r/'gui-supervisor.py'),'--profile',profile,'--port',str(port)],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
until=time.monotonic()+15
while time.monotonic()<until:
 status=r/('gui-'+profile)/'program/session.json'
 if status.is_file():
  obj=json.loads(status.read_text())
  if obj.get('state')=='ready':print(json.dumps({{'watchdog_pid':p.pid,'session':obj,'port':port,'root':str(r)}}));break
 if p.poll() is not None:raise RuntimeError((r/('watchdog-'+profile+'.stderr')).read_text())
 time.sleep(.1)
else:raise RuntimeError('Startup deadline; inspect own logs before retry')
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5','python3 -'],input=code.encode(),capture_output=True,timeout=25)
(art/('pi-model-gui-'+profile+'-started.json')).write_bytes(p.stdout);print(p.stdout.decode());print(p.stderr.decode());raise SystemExit(p.returncode)
