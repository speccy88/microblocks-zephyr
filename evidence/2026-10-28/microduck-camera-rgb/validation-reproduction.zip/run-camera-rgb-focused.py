import json,os,pathlib,shutil,subprocess,sys,tempfile,time
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';start=time.monotonic();receipts=[]
with tempfile.TemporaryDirectory(prefix='camera-rgb-focused-') as td:
 wrapper=pathlib.Path(td)/'node-interop'
 wrapper.write_text("#!/usr/bin/env python3\nimport os,subprocess,sys\nexe='/mnt/c/Users/fred_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'\nargs=[subprocess.check_output(['wslpath','-w',a],text=True).strip() if a.startswith('/') else a for a in sys.argv[1:]]\nos.execv(exe,[exe,*args])\n")
 wrapper.chmod(0o755);env=os.environ.copy();env.update(NODE_BINARY=str(wrapper),SMALLVM_MICRODUCK_BINARY='/home/fred/microduck-camera-rgb-native2-20261028/smallvm')
 for name in ('test_linux_microduck_camera_service.py','test_js_camera.py','test_camera_rgb_preview.py'):
  p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p',name,'-v'],cwd=r,env=env)
  receipts.append({'suite':name,'returncode':p.returncode})
target=a/'microduck-camera-rgb-native';target.mkdir(exist_ok=True)
for name in ('smallvm','build-manifest.json','source-manifest.json'):shutil.copyfile('/home/fred/microduck-camera-rgb-native2-20261028/'+name,target/name)
(a/'camera-rgb-focused-receipt.json').write_text(json.dumps({'suites':receipts,'seconds':time.monotonic()-start,'physical_hardware':False,'new_pi_execution':False},indent=2)+'\n')
raise SystemExit(any(p['returncode'] for p in receipts))
