import pathlib,subprocess,tempfile
r=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='rgb-unc-') as folder:
 p=pathlib.Path(folder)
 (p/'package.json').write_text('{"type":"commonjs"}')
 for name in ('tests/test_microduck_camera_rgb.cjs','web/microduck/camera-rgb.js'):
  target=p/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((r/name).read_bytes())
 script=subprocess.check_output(['wslpath','-w',str(p/'tests/test_microduck_camera_rgb.cjs')],text=True).strip()
 result=subprocess.run(['/mnt/c/Users/fred_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe','--test-reporter=tap',script],capture_output=True,text=True,timeout=30)
 print(result.stdout+result.stderr)
 assert result.returncode==0 and '# pass 6' in result.stdout
