import functools,http.server,json,os,pathlib,time
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';stop=a/'camera-rgb-server.stop'
assert not stop.exists()
handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(r/'web/microduck'))
server=http.server.HTTPServer(('127.0.0.1',18910),handler);server.timeout=.5
(a/'camera-rgb-server.json').write_text(json.dumps({'pid':os.getpid(),'address':'http://127.0.0.1:18910/camera-rgb.html','root':str(r/'web/microduck'),'lifetime_seconds':900}))
end=time.monotonic()+900
try:
 while time.monotonic()<end and not stop.exists():server.handle_request()
finally:server.server_close()
print('Owned fixture server stopped',flush=True)
