"""Query-only post-boot acceptance. Reboot is a separate explicitly authorized action."""
import hashlib,json,os,pathlib,subprocess,sys,time,urllib.request
sys.dont_write_bytecode=True;ROOT=pathlib.Path(__file__).resolve().parent
assert (ROOT/'.owned-fresh-install').read_text().strip()==str(ROOT)
sys.path.insert(0,str(ROOT/'bundle/linux/arm64'));import service
sys.path.insert(0,'/home/fred/microblocks-auto-service-o5ygmr3m/tests');from test_linux_arm64_session import WebWire
phase=sys.argv[1];file=ROOT/'reboot-receipt.json';r=json.loads(file.read_text()) if file.exists() else {'root':str(ROOT),'physical_pi':True,'physical_robot':False,'manual_bridge_restart_after_reboot':False,'checks':[]}
def save():file.write_text(json.dumps(r,indent=2)+'\n')
def boot():return pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
def services():return subprocess.check_output(['systemctl','list-units','--type=service','--state=running','--no-legend','--no-pager'],text=True)
def inspect():
 state=service.wait_ready(ROOT/'program',8876)
 assert os.readlink(f'/proc/{state["vm_pid"]}/exe')==state['binary']
 for key in ('vm_pid','bridge_pid'):assert f'PPid:\t{state["supervisor_pid"]}\n' in pathlib.Path('/proc',str(state[key]),'status').read_text()
 return state
def read_code():
 wire=WebWire(8876)
 try:wire.ping();assert wire.reporter()==42;return wire.crc()
 finally:wire.close()
if phase=='before':
 assert not file.exists();r['boot_before']=boot();r['session_before']=inspect();r['services_before']=services();r['linger_before']=subprocess.check_output(['loginctl','show-user',str(os.getuid()),'-p','Linger','--value'],text=True)
 r['crc']=read_code();raw=(ROOT/'program/program.ucode').read_bytes();r['program_sha256']=hashlib.sha256(raw).hexdigest()
 with (ROOT/'saved-before-reboot.ucode').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 r['checks'].append('Working graphical42 sealed with CRC and private fsynced backup');save();os.sync()
elif phase=='after':
 assert boot()!=r['boot_before'];r['boot_after']=boot();r['uptime_after']=pathlib.Path('/proc/uptime').read_text().strip();r['session_after']=inspect()
 assert hashlib.sha256((ROOT/'program/program.ucode').read_bytes()).hexdigest()==r['program_sha256'];assert read_code()==r['crc']
 with urllib.request.urlopen('http://127.0.0.1:8876/',timeout=3) as response:
  assert response.status==200 and b'linux-bootstrap.js' in response.read();r['automatic_http_status']=response.status
 r['unit_properties']=subprocess.check_output(['systemctl','--user','show',service.UNIT,'-p','MainPID','-p','ActiveEnterTimestampMonotonic','-p','NoNewPrivileges','-p','PrivateTmp','-p','ProtectSystem'],text=True)
 r['services_after']=services();old={x.split()[0] for x in r['services_before'].splitlines()};new={x.split()[0] for x in r['services_after'].splitlines()};r['previous_running_system_services_absent']=sorted(old-new)
 r['linger_after']=subprocess.check_output(['loginctl','show-user',str(os.getuid()),'-p','Linger','--value'],text=True);assert r['linger_after']==r['linger_before']
 r['checks'].append('New OS boot automatically starts supervisor, VM and HTTP/WebSocket bridge; saved42/CRC preserved; no server launch command issued')
 r['reboot_passed']=True;save()
elif phase=='cleanup':
 assert '# microblocks-prefix='+str(ROOT/'prefix') in (pathlib.Path.home()/'.config/systemd/user'/service.UNIT).read_text().splitlines()
 result=subprocess.run([str(ROOT/'prefix/bin/microblocks-uninstall')],capture_output=True,text=True,timeout=20)
 r['uninstall']={'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr};assert result.returncode==0
 r['program_file_retained']=(ROOT/'program/program.ucode').is_file();r['program_sha256_after_graphical']=hashlib.sha256((ROOT/'program/program.ucode').read_bytes()).hexdigest()
 r['unit_removed']=not (pathlib.Path.home()/'.config/systemd/user'/service.UNIT).exists();r['launcher_removed']=not (ROOT/'prefix/bin/smallvm').exists()
 # The visible post-boot test can synchronize the project again; validate the
 # final journal representation by a new real interpreter, not file inequality.
 from linux_arm64_protocol import Runtime
 with __import__('tempfile').TemporaryDirectory(prefix='final-code-reload-') as tmp:
  target=pathlib.Path(tmp);(target/'program.ucode').write_bytes((ROOT/'program/program.ucode').read_bytes())
  vm=Runtime(pathlib.Path(r['session_after']['binary']),target,928)
  try:r['final_saved_result']=vm.wire.reporter(0);assert r['final_saved_result']==42
  finally:vm.stop()
 save()
else:raise RuntimeError('Choose before, after or cleanup')
print(json.dumps({k:v for k,v in r.items() if k not in ('services_before','services_after')}))
