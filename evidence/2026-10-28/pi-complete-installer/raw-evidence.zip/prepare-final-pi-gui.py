import hashlib,json,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';target=json.loads((a/'pi-fresh-install-transfer.json').read_text())['root'];opts=['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes']
subprocess.run(['scp','-q',*opts,str(a/'pi-model-gui-lab.js'),'rpi5:'+target+'/lab.js'],check=True)
code=f'''import pathlib,json,hashlib,os
r=pathlib.Path({target!r});assert (r/'.owned-fresh-install').read_text().strip()==str(r)
install=json.loads((r/'install-receipt.json').read_text())['installed'];editor=pathlib.Path(install['session']['editor_directory'])
manifest=json.loads((r/'bundle/bundle-manifest.json').read_text());expected={{n.removeprefix('editor/'):h for n,h in manifest['files'].items() if n.startswith('editor/')}}
assert {{p.relative_to(editor).as_posix() for p in editor.rglob('*') if p.is_file()}}==set(expected)
for name,digest in expected.items():assert hashlib.sha256((editor/name).read_bytes()).hexdigest()==digest,name
raw=(editor/'microblocks.html').read_text();assert raw.count('</body>')==1
(r/'pre-gui-editor-verification.json').write_text(json.dumps({{'all_installed_editor_files_verified':len(expected),'bundle_archive_sha256':{json.loads((a/'pi-fresh-install-transfer.json').read_text())['archive_sha256']!r},'test_overlay_follows':True}},indent=2)+'\\n')
(editor/'Acceptance').mkdir();(editor/'Acceptance/PiArithmetic.ubp').write_text("module main\\nauthor unknown\\nversion1 0\\nscript40 60(20 +22)\\n".replace('version1','version 1').replace('script40','script 40').replace('60(','60 (').replace('+22','+ 22'))
(editor/'acceptance-lab.js').write_bytes((r/'lab.js').read_bytes())
(editor/'microblocks.html').write_text(raw.replace('</body>','<script src="acceptance-lab.js"></script>\\n</body>'))
with (editor/'files.txt').open('a') as out:out.write('Acceptance/PiArithmetic.ubp\\nacceptance-lab.js\\n')
print(json.dumps({{'test_only_overlay':True,'engine_files_changed':False,'editor':str(editor)}}))
'''
print(subprocess.check_output(['ssh',*opts,'rpi5','python3 -'],input=code.encode(),timeout=20).decode())
