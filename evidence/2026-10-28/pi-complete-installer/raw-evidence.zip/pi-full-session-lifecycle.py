"""Real disposable Pi session service: repeat install and owned-child recovery."""
import hashlib,json,os,pathlib,signal,subprocess,sys,time
sys.dont_write_bytecode=True;ROOT=pathlib.Path(__file__).resolve().parent
assert (ROOT/'.owned-fresh-install').read_text().strip()==str(ROOT)
sys.path.insert(0,str(ROOT/'bundle/linux/arm64'));import service
sys.path.insert(0,'/home/fred/microblocks-auto-service-o5ygmr3m/tests');from test_linux_arm64_session import WebWire
UNIT='microblocks-smallvm.service';port=8876;data=ROOT/'program';prefix=ROOT/'prefix';unit=pathlib.Path.home()/'.config/systemd/user'/UNIT
assert '# microblocks-prefix='+str(prefix) in unit.read_text().splitlines()
record={'root':str(ROOT),'physical_pi':True,'physical_robot':False,'checks':[]};out=ROOT/'lifecycle-receipt.json'
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def ready(old=None):
 end=time.monotonic()+20
 while time.monotonic()<end:
  state=service.wait_ready(data,port,timeout=5)
  if old is None or state['supervisor_pid']!=old:return state
  time.sleep(.1)
 raise RuntimeError('Systemd did not replace the owned failed session')
def bytecode(expected):
 w=WebWire(port)
 try:w.ping();result=w.reporter();assert result==expected;return w.crc()
 finally:w.close()
def child_start(pid):
 try:return pathlib.Path('/proc',str(pid),'stat').read_text().split()[21]
 except FileNotFoundError:return None
state=ready();record['initial_session']=state
w=WebWire(port)
try:w.ping();crc=w.upload();assert w.reporter()==12
finally:w.close()
saved=(data/'program.ucode').read_bytes();record['program_sha256']=hashlib.sha256(saved).hexdigest();save()
args=['python3','-B',str(ROOT/'bundle/linux/arm64/install_bundle.py'),'--prefix',str(prefix),'--data',str(data)]
p=subprocess.run(args,capture_output=True,text=True,timeout=45);(ROOT/'repeat.stdout').write_text(p.stdout);(ROOT/'repeat.stderr').write_text(p.stderr);assert p.returncode==0,p.stdout+p.stderr
assert json.loads(p.stdout.strip().splitlines()[-1])['unchanged'] is True
assert (data/'program.ucode').read_bytes()==saved and ready()['supervisor_pid']==state['supervisor_pid'] and bytecode(12)==crc
record['checks'].append('Identical bundle reinstallation preserves saved bytes, CRC and running supervisor');save()
for role in ('bridge_pid','vm_pid'):
 state=ready();pid=state[role];starts={key:child_start(state[key]) for key in ('supervisor_pid','bridge_pid','vm_pid')}
 status=pathlib.Path('/proc',str(pid),'status').read_text();assert f'PPid:\t{state["supervisor_pid"]}\n' in status
 if role=='vm_pid':assert os.readlink(f'/proc/{pid}/exe')==state['binary']
 else:assert str(prefix/'lib/microblocks-session') in pathlib.Path('/proc',str(pid),'cmdline').read_bytes().decode()
 os.kill(pid,signal.SIGKILL);new=ready(state['supervisor_pid'])
 assert all(child_start(state[key])!=starts[key] for key in starts)
 assert (data/'program.ucode').read_bytes()==saved and bytecode(12)==crc
 record.setdefault('recovery',[]).append({'killed_role':role,'old':state,'new':new,'all_old_owned_processes_ended':True,'program_unchanged':True})
 record['checks'].append('Automatic systemd recovery after '+role+' failure; VM and bridge both replaced, program/CRC retained');save()
record['passed']=True;record['final_session']=ready();save();print(json.dumps({'passed':True,'checks':record['checks'],'session':record['final_session']}))
