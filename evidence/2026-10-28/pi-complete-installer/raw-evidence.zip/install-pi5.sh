#!/bin/sh
set -eu
umask 077
command -v python3 >/dev/null || { echo 'Python3 is required' >&2; exit 1; }
command -v curl >/dev/null || { echo 'curl is required' >&2; exit 1; }
work=$(mktemp -d)
trap 'rm -rf -- "$work"' EXIT HUP INT TERM
curl --fail --location --proto '=https' --tlsv1.2 --max-filesize 67108864 'https://github.com/speccy88/microblocks-zephyr/releases/download/rpi5-v417-20261028-alpha1/smallvm-pi5-rpi5-v417-20261028-alpha1.tar.gz' -o "$work/bundle.tar.gz"
printf '%s  %s\n' 'edabb7b3da9d22d129b6e56c39369f89538de26b4ec3da3636c8f8375d122607' "$work/bundle.tar.gz" | sha256sum --check --status -
python3 - "$work/bundle.tar.gz" "$work/content" <<'PY'
import pathlib,sys,tarfile
archive,destination=map(pathlib.Path,sys.argv[1:]);destination.mkdir(mode=0o700)
with tarfile.open(archive,'r:gz') as bundle:
 members=bundle.getmembers();names=[m.name for m in members]
 if len(members)>5000 or len(names)!=len(set(names)) or sum(m.size for m in members)>268435456:raise SystemExit('Invalid bundle bounds')
 for m in members:
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or m.size>67108864 or p.is_absolute() or '..' in p.parts or '\\' in m.name or p.as_posix()!=m.name:raise SystemExit('Unsafe bundle member')
  target=destination/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(bundle.extractfile(m).read())
PY
python3 -B "$work/content/linux/arm64/install_bundle.py" "$@"
