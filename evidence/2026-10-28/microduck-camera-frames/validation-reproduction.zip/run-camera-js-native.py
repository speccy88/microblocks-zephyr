import json,os,pathlib,shutil,subprocess,sys,tempfile,time
r=pathlib.Path(__file__).resolve().parents[1];start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='camera-js-native-') as td:
 wrapper=pathlib.Path(td)/'node-interop'
 wrapper.write_text("#!/usr/bin/env python3\nimport os,subprocess,sys\nexe='/mnt/c/Users/fred_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'\nargs=[subprocess.check_output(['wslpath','-w',a],text=True).strip() if a.startswith('/') else a for a in sys.argv[1:]]\nos.execv(exe,[exe,*args])\n")
 wrapper.chmod(0o755)
 env=os.environ.copy();env.update(NODE_BINARY=str(wrapper),SMALLVM_MICRODUCK_BINARY='/home/fred/microduck-camera-native-20261028/smallvm')
 p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_js_camera.py','-v'],cwd=r,env=env)
 (r/'build-artifacts/camera-js-native-receipt.json').write_text(json.dumps({'returncode':p.returncode,'seconds':time.monotonic()-start,'physical_hardware':False,'graphical':False,'simulated_service':True},indent=2)+'\n')
 raise SystemExit(p.returncode)
