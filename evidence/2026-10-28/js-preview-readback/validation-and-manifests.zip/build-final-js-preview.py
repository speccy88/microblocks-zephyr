import hashlib,json,pathlib,shutil,subprocess,sys,time,zipfile
root=pathlib.Path(__file__).resolve().parents[1];art=root/'build-artifacts';sys.path.insert(0,str(root/'tools'));from package_js_site import build,hashes
source=root.parent/'microblocks-editor-upstream-20261027';gp=art/'gp-preserved-input-pi-readback';output=art/'js-all-targets-pi-readback-20261028';start=time.monotonic()
old=art/'js-all-targets-20261028-b';old_manifest=old/'js-preview/site-manifest.json';baseline=json.loads(old_manifest.read_text())['gp_files_preserved'];gp.mkdir()
for name,digest in baseline.items():
 path=pathlib.PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts
 p=old/name;assert p.resolve().is_relative_to(old.resolve()) and not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==digest
 target=gp/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
assert (gp/'index.html').is_file() and not (gp/'js-preview').exists()
report=build(source,gp,output);actual=hashes(output);assert all(actual[p]==digest for p,digest in report['files'].items());assert hashes(gp)==report['gp_files_preserved']
expected=hashlib.sha256((root/'web/js-editor/readback-compat.js').read_bytes()).hexdigest()
for profile in report['profiles']:
 folder=output/'js-preview'/profile;assert hashlib.sha256((folder/'readback-compat.js').read_bytes()).hexdigest()==expected
 m=json.loads((folder/'source-manifest.json').read_text());assert len(m['files'])==550
 for f in m['files']:
  if f['path'].startswith('engine/'):assert hashlib.sha256((folder/f['path']).read_bytes()).hexdigest()==f['sha256']
 packaged=json.loads((folder/'build-manifest.json').read_text())
 for name,record in packaged['files'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==record['sha256']
zip_path=output.with_suffix('.zip')
with zipfile.ZipFile(zip_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for path in sorted(output.rglob('*')):
  if path.is_file():
   name=path.relative_to(output).as_posix();info=zipfile.ZipInfo(name,(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,path.read_bytes())
result={'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'only_uncommitted_product_change':'P4 preview description corrected; runtime unchanged','package_recipe_sha256':hashlib.sha256((root/'tools/package_js_site.py').read_bytes()).hexdigest(),'gp_baseline_manifest_sha256':hashlib.sha256(old_manifest.read_bytes()).hexdigest(),'profiles':list(report['profiles']),'files_verified':len(actual),'gp_files_preserved':len(report['gp_files_preserved']),'upstream_source_inputs_per_profile':550,'upstream_engine_files_verified_per_profile':len([f for f in m['files'] if f['path'].startswith('engine/')]),'readback_adapter_sha256':expected,'site_manifest_sha256':hashlib.sha256((output/'js-preview/site-manifest.json').read_bytes()).hexdigest(),'output':str(output),'zip':str(zip_path),'zip_bytes':zip_path.stat().st_size,'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'seconds':time.monotonic()-start,'published':False,'runtime_upgraded':False,'graphical_acceptance_scope':'Pi standalone and representative MicroDuck fictional robotd readings only; other hardware pending'}
(art/'js-all-targets-pi-readback-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result))
