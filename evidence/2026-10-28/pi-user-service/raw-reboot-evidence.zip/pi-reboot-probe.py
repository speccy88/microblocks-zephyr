"""Two-phase real Pi reboot fixture; reboot itself is a separate authorized action."""
import hashlib,json,os,pathlib,shutil,subprocess,sys,time,socket
ROOT=pathlib.Path(__file__).resolve().parent;os.umask(0o077)
assert (ROOT/'.owned-service-acceptance').read_text().strip()==str(ROOT)
sys.path.insert(0,str(ROOT/'tests'));from test_linux_arm64_session import WebWire
UNIT='microblocks-smallvm.service';prefix=ROOT/'prefix';data=ROOT/'program';version='pi5-service-acceptance-20261028'
phase=sys.argv[1];record=ROOT/'reboot-receipt.json';r=json.loads(record.read_text()) if record.exists() else {'root':str(ROOT),'checks':[],'robot_connected':False,'network_security_changed':False}
def save():record.write_text(json.dumps(r,indent=2)+'\n')
def cmd(*args):
 p=subprocess.run(args,capture_output=True,text=True,timeout=30);r.setdefault('commands',[]).append({'args':list(args),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
 if p.returncode:raise RuntimeError('Command failed: '+p.stderr)
 return p.stdout
def props():return dict(line.split('=',1) for line in cmd('systemctl','--user','show',UNIT,'-p','MainPID','-p','ActiveState','-p','FragmentPath','-p','NoNewPrivileges','-p','PrivateTmp','-p','ProtectSystem').splitlines() if '=' in line)
def identity():return {'hostname':socket.gethostname(),'architecture':os.uname().machine,'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
def inventory():
 rows=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=os.readlink(p/'exe')
   if pathlib.Path(exe).name=='smallvm':rows.append({'pid':int(p.name),'exe':exe,'argv':(p/'cmdline').read_bytes().decode().strip('\0').split('\0'),'cwd':os.readlink(p/'cwd'),'start':(p/'stat').read_text().split()[21]})
  except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 return rows
def vm():
 end=time.monotonic()+20
 while time.monotonic()<end:
  state=props();pid=int(state.get('MainPID',0))
  try:exe=os.readlink(f'/proc/{pid}/exe') if pid else ''
  except (PermissionError,FileNotFoundError,ProcessLookupError):time.sleep(.2);continue
  if pid and state['ActiveState']=='active':
   assert pathlib.Path(exe).resolve()==(prefix/'lib/microblocks'/version/'smallvm').resolve()
   assert state['NoNewPrivileges']=='yes' and state['PrivateTmp']=='yes' and state['ProtectSystem']=='strict'
   for f in data.glob('pty-*.json'):
    if json.loads(f.read_text())['pid']==pid:return f,state
  time.sleep(.2)
 raise RuntimeError('Service did not become ready')
def bridge(info):
 port=52591
 with socket.socket() as s:s.bind(('127.0.0.1',port))
 editor=ROOT/'editor-current'
 assert (editor/'readback-compat.js').is_file() and (editor/'microblocks.html').is_file()
 assert hashlib.sha256((editor/'readback-compat.js').read_bytes()).hexdigest()=='703b92381bd8cc0831ccdc407a03005ef8a8f21523832f15d72942f6deb05fab'
 log=(ROOT/('reboot-bridge-'+phase+'.log')).open('x')
 p=subprocess.Popen([sys.executable,str(ROOT/'linux/arm64/bridge.py'),'--editor',str(editor),'--pty-info',str(info),'--vm-executable',str(prefix/'lib/microblocks'/version/'smallvm'),'--http-port',str(port)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 r['bridge_'+phase]={'pid':p.pid,'port':port,'start':pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]};save()
 end=time.monotonic()+8
 while time.monotonic()<end:
  if p.poll() is not None:raise RuntimeError('Bridge exited')
  try:return WebWire(port)
  except OSError:time.sleep(.1)
 raise RuntimeError('Bridge startup timeout')
if phase=='before':
 assert not record.exists();assert not (pathlib.Path.home()/'.config/systemd/user'/UNIT).exists()
 r['identity_before']=identity();r['vms_before']=inventory()
 r['services_before']=cmd('systemctl','list-units','--type=service','--state=running','--plain','--no-legend','--no-pager')
 r['user_failed_before']=cmd('systemctl','--user','list-units','--failed','--no-legend','--no-pager')
 r['linger_before']=cmd('loginctl','show-user',str(os.getuid()),'-p','Linger','--value')
 backup=ROOT/'preexisting-program-backups';backup.mkdir(mode=0o700);r['preexisting_saved_files']=[]
 for row in r['vms_before']:
  argv=row['argv'];folder=pathlib.Path(argv[argv.index('--data-dir')+1] if '--data-dir' in argv else row['cwd'])
  for name in ('program.ucode','program.ucode.bak','ublockscode'):
   source=folder/name
   if source.is_file() and not source.is_symlink():
    raw=source.read_bytes();assert raw==source.read_bytes(),'Saved program changing; postpone reboot'
    target=backup/(str(row['pid'])+'-'+name)
    with target.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    r['preexisting_saved_files'].append({'path':str(source),'backup':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 save()
 cmd('bash',str(ROOT/'install.sh'),'--version',version,'--sha256',(ROOT/'candidate.sha256').read_text().split()[0],'--archive',str(ROOT/'candidate.tar.gz'),'--prefix',str(prefix),'--data-dir',str(data),'--service')
 info,state=vm();r['service_before']=state;wire=bridge(info)
 try:wire.ping();r['crc']=wire.upload();assert wire.reporter()==12
 finally:wire.close()
 raw=(data/'program.ucode').read_bytes();r['program_sha256']=hashlib.sha256(raw).hexdigest()
 with (ROOT/'own-program-backup.ucode').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 r['checks'].append('Pre-reboot actual service active and bytecode12 persisted');r['ready_for_authorized_reboot']=True;save();os.sync()
elif phase=='resume-before':
 assert identity()['boot_id']==r['identity_before']['boot_id'] and not r.get('ready_for_authorized_reboot')
 info,state=vm();r['service_before']=state;wire=bridge(info)
 try:wire.ping();r['crc']=wire.upload();assert wire.reporter()==12
 finally:wire.close()
 raw=(data/'program.ucode').read_bytes();r['program_sha256']=hashlib.sha256(raw).hexdigest()
 with (ROOT/'own-program-backup.ucode').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 r['checks'].append('Pre-reboot actual service active and bytecode12 persisted');r['ready_for_authorized_reboot']=True;save();os.sync()
elif phase=='seal':
 assert identity()['boot_id']==r['identity_before']['boot_id']
 wire=WebWire(52591)
 try:wire.ping();assert wire.reporter()==42;r['crc']=wire.crc()
 finally:wire.close()
 raw=(data/'program.ucode').read_bytes();r['program_sha256']=hashlib.sha256(raw).hexdigest();r['expected_result']=42
 with (ROOT/'sealed-graphical-program.ucode').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 r['checks'].append('Editor graphical42 and protocol42; final program privately sealed before reboot');save();os.sync()
elif phase=='after':
 assert r['ready_for_authorized_reboot'] and identity()['boot_id']!=r['identity_before']['boot_id']
 r['identity_after']=identity();info,state=vm();r['service_after']=state
 assert hashlib.sha256((data/'program.ucode').read_bytes()).hexdigest()==r['program_sha256']
 r['preexisting_saved_files_preserved']=all(pathlib.Path(f['path']).is_file() and hashlib.sha256(pathlib.Path(f['path']).read_bytes()).hexdigest()==f['sha256'] for f in r['preexisting_saved_files'])
 assert r['preexisting_saved_files_preserved']
 wire=bridge(info)
 try:wire.ping();assert wire.crc()==r['crc'] and wire.reporter()==r['expected_result']
 finally:wire.close()
 r['services_after']=cmd('systemctl','list-units','--type=service','--state=running','--plain','--no-legend','--no-pager');r['vms_after']=inventory()
 r['user_failed_after']=cmd('systemctl','--user','list-units','--failed','--no-legend','--no-pager');r['linger_after']=cmd('loginctl','show-user',str(os.getuid()),'-p','Linger','--value');assert r['linger_before']==r['linger_after']
 r['checks'].append('Different Linux boot; service auto-started, saved bytecode42 and CRC preserved; manual foreground bridge reconnected')
 r['reboot_passed']=True;save()
elif phase=='cleanup':
 for key in ('bridge_before','bridge_after'):
  entry=r.get(key)
  if not entry:continue
  p=pathlib.Path('/proc',str(entry['pid']))
  if p.exists() and (p/'stat').read_text().split()[21]==entry['start']:
   argv=(p/'cmdline').read_bytes().decode().split('\0');assert str(ROOT/'linux/arm64/bridge.py') in argv
   os.kill(entry['pid'],15)
 cmd('bash',str(ROOT/'uninstall.sh'),'--prefix',str(prefix))
 r['test_unit_removed']=not (pathlib.Path.home()/'.config/systemd/user'/UNIT).exists();r['test_launcher_removed']=not (prefix/'bin/smallvm').exists();r['program_retained']=hashlib.sha256((data/'program.ucode').read_bytes()).hexdigest()==r['program_sha256'];r['vms_final']=inventory();save()
else:raise RuntimeError('Choose before, after or cleanup')
print(json.dumps({k:v for k,v in r.items() if k not in ('commands','services_before','services_after')}))
