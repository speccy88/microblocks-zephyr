import hashlib,json,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parents[1];art=r/'build-artifacts';opts=['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes']
manifest=json.loads((art/'pi-model-gui-20261028/kit-manifest.json').read_text(encoding='utf-8'))
files={k.removeprefix('editor-pi/'):v for k,v in manifest['files'].items() if k.startswith('editor-pi/')}
code=f'''import pathlib,shutil,json,hashlib
root=pathlib.Path('/home/fred/microblocks-service-test-2n155u0n');assert (root/'.owned-service-acceptance').read_text().strip()==str(root)
source=pathlib.Path('/home/fred/microblocks-model-gui-akw9ddnn/editor-pi');expected={files!r}
for name,digest in expected.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
target=root/'editor-current';assert not target.exists();shutil.copytree(source,target)
print(json.dumps({{'copied_verified_editor_files':len(expected)}}))
'''
print(subprocess.check_output(['ssh',*opts,'rpi5','python3 -'],input=code.encode(),timeout=60).decode())
subprocess.run(['scp','-q',*opts,str(r/'web/js-editor/readback-compat.js'),'rpi5:/home/fred/microblocks-service-test-2n155u0n/editor-current/readback-compat.js'],check=True)
subprocess.run(['scp','-q',*opts,str(art/'pi-reboot-probe.py'),'rpi5:/home/fred/microblocks-service-test-2n155u0n/reboot-probe.py'],check=True)
