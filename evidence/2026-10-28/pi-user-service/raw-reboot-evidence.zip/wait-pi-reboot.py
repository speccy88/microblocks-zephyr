import json,pathlib,subprocess,time
r=pathlib.Path(__file__).resolve().parents[1];out=r/'build-artifacts/pi-reboot-reconnect.json';before=json.loads((r/'build-artifacts/pi-reboot-before-receipt.json').read_text())['identity_before']['boot_id'];start=time.monotonic();attempts=[]
code="import pathlib,json,os,socket;print(json.dumps({'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'uptime':pathlib.Path('/proc/uptime').read_text().strip(),'hostname':socket.gethostname(),'machine':os.uname().machine}))"
while time.monotonic()-start<45:
 try:
  p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=3','rpi5','python3 -'],input=code.encode(),capture_output=True,timeout=6)
  row={'seconds':time.monotonic()-start,'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()};attempts.append(row)
  if p.returncode==0:
   new=json.loads(row['stdout'])
   if new['boot_id']!=before:
    assert new['hostname']=='RPI5' and new['machine']=='aarch64';out.write_text(json.dumps({'returned':True,'identity':new,'attempts':attempts},indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(new));break
 except subprocess.TimeoutExpired:attempts.append({'seconds':time.monotonic()-start,'timeout':True})
 time.sleep(3)
else:
 out.write_text(json.dumps({'returned':False,'attempts':attempts},indent=2)+'\n',encoding='utf-8',newline='\n');raise SystemExit('Pi return not yet verified; no reboot repeated')
