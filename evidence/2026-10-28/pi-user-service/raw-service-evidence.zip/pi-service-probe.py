"""Real opt-in installer/user-manager test; no reboot, lingering or other VMs."""
import hashlib,json,os,pathlib,signal,socket,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;os.umask(0o077);UNIT='microblocks-smallvm.service';version='pi5-service-acceptance-20261028'
sys.path.insert(0,str(ROOT/'tests'));from test_linux_arm64_session import WebWire
prefix=ROOT/'prefix';data=ROOT/'program';unit=pathlib.Path.home()/'.config/systemd/user'/UNIT
report={'root':str(ROOT),'architecture':os.uname().machine,'reboot':False,'lingering_changed':False,'other_services_changed':False,'checks':[]};bridges=[];started=False
def save(): (ROOT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def command(*args,check=True):
 p=subprocess.run(args,capture_output=True,text=True,timeout=25)
 report.setdefault('commands',[]).append({'args':list(args),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
 if check and p.returncode:raise RuntimeError('Command failed: '+' '.join(args[:4]))
 return p
def props():
 p=command('systemctl','--user','show',UNIT,'-p','MainPID','-p','ActiveState','-p','SubState','-p','NoNewPrivileges','-p','PrivateTmp','-p','ProtectSystem','-p','NRestarts','-p','FragmentPath')
 return dict(line.split('=',1) for line in p.stdout.splitlines() if '=' in line)
def wait_vm(old=None):
 until=time.monotonic()+15
 while time.monotonic()<until:
  state=props();pid=int(state.get('MainPID',0))
  if pid and pid!=old and state.get('ActiveState')=='active':
   try:exe=pathlib.Path(os.readlink(f'/proc/{pid}/exe')).resolve()
   except (PermissionError,FileNotFoundError,ProcessLookupError):time.sleep(.15);continue
   assert exe==(prefix/'lib/microblocks'/version/'smallvm').resolve()
   for path in data.glob('pty-*.json'):
    info=json.loads(path.read_text())
    if info['pid']==pid:return pid,path,state
  time.sleep(.15)
 raise RuntimeError('Owned service did not publish a fresh verified VM')
def start_bridge(info):
 with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
 number=len(bridges);log=(ROOT/f'bridge-{number}.log').open('x')
 p=subprocess.Popen([sys.executable,str(ROOT/'linux/arm64/bridge.py'),'--editor',str(ROOT/'editor'),'--pty-info',str(info),'--vm-executable',str(prefix/'lib/microblocks'/version/'smallvm'),'--http-port',str(port)],stdout=log,stderr=subprocess.STDOUT)
 bridges.append((p,log));until=time.monotonic()+6
 while time.monotonic()<until:
  if p.poll() is not None:raise RuntimeError('Own bridge exited; inspect log')
  try:return p,port,WebWire(port)
  except OSError:time.sleep(.05)
 raise RuntimeError('Own bridge startup deadline')
def stop_bridge(p):
 if p.poll() is None:p.terminate();p.wait(timeout=7)
def inventory():
 rows=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=os.readlink(p/'exe')
   if pathlib.Path(exe).name=='smallvm':rows.append({'pid':int(p.name),'exe':exe,'start':(p/'stat').read_text().split()[21]})
  except (PermissionError,FileNotFoundError,ProcessLookupError):pass
 return rows
def interrupted(signum,frame):raise RuntimeError('Test interrupted; clean up owned service')
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupted)
assert (ROOT/'.owned-service-acceptance').read_text().strip()==str(ROOT)
assert not unit.exists() and not unit.is_symlink(),'Canonical user unit already exists; refusing to replace it'
load=command('systemctl','--user','show',UNIT,'-p','LoadState','-p','ActiveState','-p','FragmentPath',check=False).stdout
assert 'LoadState=not-found' in load and 'FragmentPath=\n' in load
before=inventory();report['vms_before']=before
failed=command('systemctl','--user','list-units','--failed','--no-legend','--no-pager').stdout;report['failed_units_before']=failed
linger=command('loginctl','show-user',str(os.getuid()),'-p','Linger','--value').stdout;report['linger_before']=linger
try:
 digest=(ROOT/'candidate.sha256').read_text().split()[0]
 report['stage']='install actual service';save();started=True
 command('bash',str(ROOT/'install.sh'),'--version',version,'--sha256',digest,'--archive',str(ROOT/'candidate.tar.gz'),'--prefix',str(prefix),'--data-dir',str(data),'--service')
 pid,info,state=wait_vm();assert state['NoNewPrivileges']=='yes' and state['PrivateTmp']=='yes' and state['ProtectSystem']=='strict'
 report['initial_service']=state;report['checks'].append('Actual service active with installer hardening unchanged')
 bridge,port,wire=start_bridge(info)
 try:wire.ping();crc=wire.upload();assert wire.reporter()==12
 finally:wire.close()
 wire=WebWire(port)
 try:wire.ping();assert wire.crc()==crc and wire.reporter()==12
 finally:wire.close()
 saved=(data/'program.ucode').read_bytes();report['program_sha256']=hashlib.sha256(saved).hexdigest();report['checks'].append('Actual bytecode12, acknowledged upload CRC and WebSocket reconnect')
 stop_bridge(bridge)
 command('systemctl','--user','restart',UNIT);pid2,info,state=wait_vm(pid);assert (data/'program.ucode').read_bytes()==saved
 bridge,port,wire=start_bridge(info)
 try:wire.ping();assert wire.crc()==crc and wire.reporter()==12
 finally:wire.close()
 report['checks'].append('Explicit systemd restart preserves program and reconnects bridge');stop_bridge(bridge)
 assert int(props()['MainPID'])==pid2
 command('systemctl','--user','kill','--kill-whom=main','--signal=SIGKILL',UNIT)
 pid3,info,state=wait_vm(pid2);assert int(state['NRestarts'])>=1 and (data/'program.ucode').read_bytes()==saved
 bridge,port,wire=start_bridge(info)
 try:wire.ping();assert wire.crc()==crc and wire.reporter()==12
 finally:wire.close()
 report['checks'].append('Restart=on-failure recovers only owned killed VM; saved code retained');report['recovered_service']=state;stop_bridge(bridge)
 report['passed']=True
except Exception as error:report['passed']=False;report['error']=str(error)
finally:
 for process,log in bridges:
  stop_bridge(process);log.close()
 if started and (prefix/'lib/microblocks/INSTALLATION').is_file():
  if unit.exists():assert ('# microblocks-prefix='+str(prefix)) in unit.read_text()
  command('bash',str(ROOT/'uninstall.sh'),'--prefix',str(prefix),check=False)
 report['unit_removed']=not unit.exists() and not unit.is_symlink();report['launcher_removed']=not (prefix/'bin/smallvm').exists()
 report['program_retained']=(data/'program.ucode').is_file()
 if 'program_sha256' in report:assert hashlib.sha256((data/'program.ucode').read_bytes()).hexdigest()==report['program_sha256']
 after=inventory();report['vms_after']=after;report['preexisting_vms_preserved']=all(row in after for row in before)
 report['failed_units_after']=command('systemctl','--user','list-units','--failed','--no-legend','--no-pager').stdout
 report['linger_after']=command('loginctl','show-user',str(os.getuid()),'-p','Linger','--value').stdout
 report['cleanup_passed']=report['unit_removed'] and report['launcher_removed'] and report['preexisting_vms_preserved'] and report['failed_units_after']==failed and report['linger_after']==linger
 save()
print(json.dumps({k:v for k,v in report.items() if k!='commands'}));raise SystemExit(0 if report.get('passed') and report['cleanup_passed'] else 1)
