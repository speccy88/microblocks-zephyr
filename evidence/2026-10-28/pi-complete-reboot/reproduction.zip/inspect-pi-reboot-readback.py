import json,pathlib,shlex,subprocess,sys
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';s=json.loads((a/'pi-approved-reboot-before.json').read_text());python=shlex.split(next(x for x in s['unit'].splitlines() if x.startswith('ExecStart=')).removeprefix('ExecStart='))[0]
code=r'''import hashlib,json,pathlib,sys
root=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5');assert (root/'.owned-fresh-install').read_text().strip()==str(root)
sys.path.insert(0,'/home/fred/microblocks-auto-service-o5ygmr3m/tests');from test_linux_arm64_session import WebWire
errors=[];crc=None;chunks=[];w=WebWire(8876)
try:
 w.ping()
 try:crc=w.crc()
 except TimeoutError:errors.append('No CRC for chunk zero')
 w.short(13,1)
 try:
  while True:
   data=w.ws.recv(timeout=1)
   if isinstance(data,bytes):chunks.append(data.hex())
 except TimeoutError:pass
finally:w.close()
print(json.dumps({'saved_sha256':hashlib.sha256((root/'program/program.ucode').read_bytes()).hexdigest(),'saved_bytes':(root/'program/program.ucode').stat().st_size,'crc':crc,'frames':chunks,'query_errors':errors,'lab_source':(root/'lab.js').read_text()}))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5',shlex.quote(python)+' -B -'],input=code.encode(),capture_output=True,timeout=15)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
report=json.loads(p.stdout);label=sys.argv[1];assert label in ('restored','after-read','after-eval','reconnected')
(a/('pi-approved-reboot-readback-'+label+'.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in report.items() if k!='lab_source'}))
