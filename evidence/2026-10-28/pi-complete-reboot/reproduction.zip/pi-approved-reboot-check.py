"""Read-only fresh inventory. Does not reboot, install, start, or stop anything."""
import json,pathlib,subprocess,sys
r=pathlib.Path(__file__).resolve().parents[1]
code=r'''import hashlib,json,os,pathlib,socket,subprocess
root=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5')
assert (root/'.owned-fresh-install').read_text().strip()==str(root)
old=json.loads((root/'reboot-receipt.json').read_text())
state=json.loads((root/'program/session.json').read_text())
unit=pathlib.Path.home()/'.config/systemd/user/microblocks-smallvm.service'
text=unit.read_text();assert '# microblocks-prefix='+str(root/'prefix') in text.splitlines()
boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert socket.gethostname()=='RPI5' and os.uname().machine=='aarch64' and os.getuid()==1000
raw=(root/'program/program.ucode').read_bytes();sha=hashlib.sha256(raw).hexdigest()
assert raw==(root/'program/program.ucode').read_bytes()
assert sha==old['program_sha256']==hashlib.sha256((root/'saved-before-reboot.ucode').read_bytes()).hexdigest()
assert hashlib.sha256(pathlib.Path(state['binary']).read_bytes()).hexdigest()=='feea4dc52f7a4e083c6144bfa569518bd801cc62341dca04500464b3c4ac7b21'
cmd=lambda *a:subprocess.check_output(a,text=True,timeout=10)
props=cmd('systemctl','--user','show','microblocks-smallvm.service','-p','MainPID','-p','ActiveState','-p','SubState','-p','UnitFileState','-p','ActiveEnterTimestampMonotonic','-p','NoNewPrivileges','-p','PrivateTmp','-p','ProtectSystem')
assert 'ActiveState=active' in props and 'MainPID='+str(state['supervisor_pid']) in props
assert state['state']=='ready' and state['bind']=='127.0.0.1' and state['port']==8876
for key in ('vm_pid','bridge_pid'):
 assert f'PPid:\t{state["supervisor_pid"]}\n' in pathlib.Path('/proc',str(state[key]),'status').read_text()
vms=[]
for path in pathlib.Path('/proc').iterdir():
 if not path.name.isdigit():continue
 try:
  exe=os.readlink(path/'exe')
  if pathlib.Path(exe).name=='smallvm':vms.append({'pid':int(path.name),'exe':exe,'cwd':os.readlink(path/'cwd')})
 except (PermissionError,FileNotFoundError,ProcessLookupError):pass
print(json.dumps({'hostname':socket.gethostname(),'architecture':os.uname().machine,'uid':os.getuid(),'boot_id':boot,'old_boot_id':old['boot_before'],'saved_sha256':sha,'expected_crc':old['crc'],'private_backup_verified':True,'session':state,'unit':text,'unit_properties':props,'vms':vms,'services':cmd('systemctl','list-units','--type=service','--state=running','--no-legend','--no-pager'),'linger':cmd('loginctl','show-user','1000','-p','Linger','--value'),'probe_sha256':hashlib.sha256((root/'pi-bundle-reboot.py').read_bytes()).hexdigest() if (root/'pi-bundle-reboot.py').exists() else None,'files':[p.name for p in root.iterdir()]}))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','rpi5','python3 -'],input=code.encode(),capture_output=True,timeout=40)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
s=json.loads(p.stdout);(r/'build-artifacts/pi-approved-reboot-before.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:s[k] for k in ('hostname','architecture','boot_id','old_boot_id','saved_sha256','expected_crc','private_backup_verified','unit_properties','vms','files')}))
