import hashlib,json,pathlib,shlex,subprocess
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';before=json.loads((a/'pi-approved-reboot-before.json').read_text());python=shlex.split(next(x for x in before['unit'].splitlines() if x.startswith('ExecStart=')).removeprefix('ExecStart='))[0]
digest=hashlib.sha256((a/'pi-bundle-reboot.py').read_bytes()).hexdigest()
code=f'''import hashlib,pathlib,runpy,sys
p=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5/bundle-reboot.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=={digest!r}
sys.argv=[str(p),'cleanup'];runpy.run_path(str(p),run_name='__main__')
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5',shlex.quote(python)+' -B -'],input=code.encode(),capture_output=True,timeout=45)
(a/'pi-approved-reboot-cleanup.stdout').write_bytes(p.stdout);(a/'pi-approved-reboot-cleanup.stderr').write_bytes(p.stderr)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
s=json.loads(p.stdout);assert s['uninstall']['returncode']==0 and s['program_file_retained'] and s['unit_removed'] and s['launcher_removed'] and s['final_saved_result']==42
(a/'pi-approved-reboot-cleanup.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:s[k] for k in ('uninstall','program_file_retained','unit_removed','launcher_removed','program_sha256_after_graphical','final_saved_result')}))
