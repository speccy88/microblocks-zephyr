"""Reconcile completed uninstall; never invokes uninstall or restarts a service."""
import json,pathlib,shlex,subprocess
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';before=json.loads((a/'pi-approved-reboot-before.json').read_text());python=shlex.split(next(x for x in before['unit'].splitlines() if x.startswith('ExecStart=')).removeprefix('ExecStart='))[0]
code=r'''import hashlib,json,os,pathlib,subprocess,sys,tempfile
root=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5');assert (root/'.owned-fresh-install').read_text().strip()==str(root)
receipt=json.loads((root/'reboot-receipt.json').read_text());binary=pathlib.Path(receipt['session_after']['binary'])
assert not (pathlib.Path.home()/'.config/systemd/user/microblocks-smallvm.service').exists()
assert not (root/'prefix/bin/smallvm').exists() and binary.is_file()
raw=(root/'program/program.ucode').read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha==receipt['program_sha256']
assert raw==(root/'saved-before-reboot.ucode').read_bytes()
sys.path.insert(0,'/home/fred/microblocks-auto-service-o5ygmr3m/tests');from linux_arm64_protocol import Runtime
with tempfile.TemporaryDirectory(prefix='verified-retained-program-') as folder:
 data=pathlib.Path(folder);target=data/'program.ucode'
 with target.open('xb') as f:os.chmod(target,0o600);f.write(raw);f.flush();os.fsync(f.fileno())
 vm=Runtime(binary,data,929)
 try:result=vm.wire.reporter(0);assert result==42
 finally:vm.stop()
vms=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=os.readlink(p/'exe')
  if pathlib.Path(exe).name=='smallvm':vms.append({'pid':int(p.name),'exe':exe})
 except (PermissionError,FileNotFoundError,ProcessLookupError):pass
services=subprocess.check_output(['systemctl','list-units','--type=service','--state=running','--no-legend','--no-pager'],text=True)
report={'uninstall_not_repeated':True,'unit_removed':True,'launcher_removed':True,'retained_program_sha256':sha,'original_backup_retained':True,'retained_program_result':result,'remaining_vms':vms,'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'linger':subprocess.check_output(['loginctl','show-user','1000','-p','Linger','--value'],text=True),'running_services':services,'verification_copy_private_mode':'0600','earlier_probe_error':'Post-uninstall reload fixture used a non-private copy; runtime correctly refused it; original program was unchanged.'}
assert not vms
(root/'final-retained-program.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5',shlex.quote(python)+' -B -'],input=code.encode(),capture_output=True,timeout=25)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
s=json.loads(p.stdout);s['previous_system_services_absent']=sorted({x.split()[0] for x in before['services'].splitlines()}-{x.split()[0] for x in s['running_services'].splitlines()});assert s['linger']==before['linger'] and s['boot_id']=='2f648fa6-81dd-4fa0-99d3-e796a17faf38'
(a/'pi-approved-reboot-final.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in s.items() if k!='running_services'}))
