import hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile,time
src=pathlib.Path(__file__).resolve().parents[1];out=src/'build-artifacts';base=pathlib.Path(tempfile.mkdtemp(prefix='js-editor-validation-',dir='/tmp'));replica=base/'repo';start=time.monotonic()
inputs=json.loads((out/'pi-complete-reboot-validation-inputs.json').read_text());bundle=out/'pi-complete-reboot-validation-base.bundle';assert hashlib.sha256(bundle.read_bytes()).hexdigest()==inputs['bundle_sha256']
subprocess.run(['git','clone','--no-checkout',str(bundle),str(replica)],check=True,capture_output=True,timeout=120)
subprocess.run(['git','-C',str(replica),'checkout','--detach',inputs['git_base']],check=True,capture_output=True,timeout=60)
records={}
def copy(source,target,label):
 assert source.is_file() and not source.is_symlink();raw=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);assert target.read_bytes()==raw;records[label]=hashlib.sha256(raw).hexdigest()
for name,digest in sorted(inputs['files'].items()):
 assert '..' not in pathlib.PurePosixPath(name).parts;copy(src/name,replica/name,name);assert records[name]==digest
gp=src.parent/'microblocks-zephyr-integration-20261027/build-artifacts/ide-source'
for path in sorted(gp.rglob('*')):
 if path.is_file():copy(path,replica/'build-artifacts/ide-source'/path.relative_to(gp),'gp-assets/'+path.relative_to(gp).as_posix())
saved=out/'microduck-camera-rgb-native'
manifest=json.loads((saved/'build-manifest.json').read_text())
assert manifest['sanitize'] and manifest['self_test']=='PASS' and manifest['source_commit']=='2071df569623ba9cdcd6f8106b61796e047df38b'
for record in manifest['sources'].values():
 if 'port_source' in record: assert hashlib.sha256((replica/record['port_source']).read_bytes()).hexdigest()==record['prepared_sha256'],record['port_source']
assert manifest['sources']['vm/runtime.c']['prepared_sha256']=='27a158cfcc7c129adbb86de74e4f2abeb11526c034720756f8613c789ef2dd1b'
binary=replica/'build-artifacts/verified-native/smallvm';copy(saved/'smallvm',binary,'native');binary.chmod(0o755)
assert records['native']==manifest['binary_sha256']=='50685320b3a419158a66c5d6d5fe57b4eb68b400c3b63ddb4634cd45d6632d71'

upstream=base/'smallvm';subprocess.run(['git','clone','--no-hardlinks','--no-checkout',str(src.parent/'smallvm-linux-upstream'),str(upstream)],check=True,capture_output=True,timeout=120)
assert subprocess.check_output(['git','-C',str(upstream),'rev-parse','2071df569623ba9cdcd6f8106b61796e047df38b^{tree}'],text=True).strip()=='5699b1a910c64cf5e6ade8c89e510627383013ad'
env=os.environ.copy();env.update(SMALLVM_MICRODUCK_BINARY=str(binary),SMALLVM_NUMERIC_BINARY=str(binary),SMALLVM_UPSTREAM=str(upstream),JS_EDITOR_UPSTREAM=str(src.parent/'microblocks-editor-upstream-20261027'))
node=shutil.which('node')
if not node:
 wrapper=base/'node-windows-interop'
 wrapper.write_text("#!/usr/bin/env python3\nimport os,subprocess,sys\nexe='/mnt/c/Users/fred_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'\nargs=[subprocess.check_output(['wslpath','-w',a],text=True).strip() if a.startswith('/') else a for a in sys.argv[1:]]\nos.execv(exe,[exe,*args])\n")
 wrapper.chmod(0o755);node=str(wrapper)
env['NODE_BINARY']=node
record={'replica':str(replica),'git_base':inputs['git_base'],'files':records,'deadlines_exclusions_relaxed':False,'fixture_counts_updated_for_added_functions':False,'empty_connection_pinned_editor_cases':7,'preparation_seconds':time.monotonic()-start,'node':node}
(out/'pi-complete-reboot-full-replica.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'}),flush=True)
start=time.monotonic();p=subprocess.run([sys.executable,'tools/validate.py'],cwd=replica,env=env,stderr=subprocess.STDOUT)
post_bad=[name for name,digest in inputs['files'].items() if hashlib.sha256((replica/name).read_bytes()).hexdigest()!=digest or hashlib.sha256((src/name).read_bytes()).hexdigest()!=digest]
receipt={'returncode':p.returncode if not post_bad else 93,'validator_returncode':p.returncode,'post_validation_source_hashes_match':not post_bad,'post_validation_source_inputs':len(inputs['files']),'post_validation_mismatches':post_bad,'seconds':time.monotonic()-start,'mode':'Full unchanged validator, byte-identical entire repository Linux filesystem replica','files':len(inputs['files']),'replica':str(replica),'environment':{k:env[k] for k in ('SMALLVM_MICRODUCK_BINARY','SMALLVM_NUMERIC_BINARY','SMALLVM_UPSTREAM','JS_EDITOR_UPSTREAM','NODE_BINARY')}}
(out/'pi-complete-reboot-full-validation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(receipt['returncode'])
