"""Restore only the owned, hash-verified arithmetic fixture and two editor adapters."""
import base64,hashlib,json,pathlib,shlex,subprocess
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts'
payload={}
for name,source in [('readback-compat.js','web/js-editor/readback-compat.js'),('linux-bootstrap.js','web/js-editor/bootstrap.js')]:
 old=subprocess.check_output(['git','show','0d3999123bbd0296a9523222f8b441e3917543a9:'+source],cwd=r);raw=(r/source).read_bytes()
 payload[name]={'old_sha256':hashlib.sha256(old).hexdigest(),'new_sha256':hashlib.sha256(raw).hexdigest(),'base64':base64.b64encode(raw).decode()}
code='payload='+repr(payload)+'\n'+r'''import base64,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5');assert (root/'.owned-fresh-install').read_text().strip()==str(root)
unit='microblocks-smallvm.service';unit_path=pathlib.Path.home()/'.config/systemd/user'/unit
assert '# microblocks-prefix='+str(root/'prefix') in unit_path.read_text().splitlines()
state=json.loads((root/'program/session.json').read_text());editor=pathlib.Path(state['editor_directory']);assert editor.is_relative_to(root/'prefix/share/microblocks-editor')
assert int(subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','--value']))==state['supervisor_pid']
raw=(root/'saved-before-reboot.ucode').read_bytes();expected='e1670b43577fb8aa7335fdd4fbef213d482c79874db785842275e6aca3325600';assert hashlib.sha256(raw).hexdigest()==expected
assert hashlib.sha256((root/'program/program.ucode').read_bytes()).hexdigest()=='2d556dff0157cd804851fac5c6ed0ad2466a5081f461d92ff4fc4d5ebf38856b'
for name,item in payload.items():
 assert hashlib.sha256((editor/name).read_bytes()).hexdigest()==item['old_sha256'],name
 assert hashlib.sha256(base64.b64decode(item['base64'])).hexdigest()==item['new_sha256']
receipt=root/'reconnect-repair.json';assert not receipt.exists()
report={'phase':'verified','manual_service_restart_after_boot_acceptance':True,'original_session':state,'adapter_hashes':{n:{k:v for k,v in p.items() if k!='base64'} for n,p in payload.items()},'backup_sha256':expected,'network_security_changed':False}
save=lambda:receipt.write_text(json.dumps(report,indent=2)+'\n')
save();backup=root/'reconnect-original-adapters';backup.mkdir(mode=0o700)
for name in payload:(backup/name).write_bytes((editor/name).read_bytes())
subprocess.run(['systemctl','--user','stop',unit],check=True,timeout=20);report['phase']='stopped';save()
for key in ('supervisor_pid','vm_pid','bridge_pid'):assert not pathlib.Path('/proc',str(state[key])).exists()
tmp=root/'program/reconnect-restored.tmp'
with tmp.open('xb') as stream:os.chmod(tmp,0o600);stream.write(raw);stream.flush();os.fsync(stream.fileno())
os.replace(tmp,root/'program/program.ucode')
for name,item in payload.items():(editor/name).write_bytes(base64.b64decode(item['base64']))
report['phase']='restored-and-patched';save()
subprocess.run(['systemctl','--user','start',unit],check=True,timeout=30);report['phase']='started';save()
print(json.dumps(report))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5','python3 -B -'],input=code.encode(),capture_output=True,timeout=65)
(a/'pi-approved-reboot-repair.stdout').write_bytes(p.stdout);(a/'pi-approved-reboot-repair.stderr').write_bytes(p.stderr)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
report=json.loads(p.stdout);(a/'pi-approved-reboot-repair.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report))
