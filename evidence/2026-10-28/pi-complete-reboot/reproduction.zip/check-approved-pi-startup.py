import hashlib,json,pathlib,shlex,subprocess
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';before=json.loads((a/'pi-approved-reboot-before.json').read_text())
line=next(x for x in before['unit'].splitlines() if x.startswith('ExecStart='));python=shlex.split(line.removeprefix('ExecStart='))[0]
assert python.startswith('/home/fred/microblocks-fresh-install-afcxpmc5/prefix/lib/microblocks-python/') and python.endswith('/bin/python')
digest=hashlib.sha256((a/'pi-bundle-reboot.py').read_bytes()).hexdigest()
code=f'''import hashlib,pathlib,runpy,sys
p=pathlib.Path('/home/fred/microblocks-fresh-install-afcxpmc5/bundle-reboot.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=={digest!r}
sys.argv=[str(p),'after'];runpy.run_path(str(p),run_name='__main__')
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','rpi5',shlex.quote(python)+' -B -'],input=code.encode(),capture_output=True,timeout=45)
(a/'pi-approved-reboot-startup.stdout').write_bytes(p.stdout);(a/'pi-approved-reboot-startup.stderr').write_bytes(p.stderr)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
s=json.loads(p.stdout);assert s['reboot_passed'] and s['boot_after']!=before['boot_id']
assert s['program_sha256']==before['saved_sha256'] and s['crc']==before['expected_crc']
(a/'pi-approved-reboot-startup.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:s[k] for k in ('boot_after','session_after','program_sha256','crc','automatic_http_status','unit_properties','previous_running_system_services_absent','reboot_passed')}))
