import datetime,json,pathlib,subprocess,time
r=pathlib.Path(__file__).resolve().parents[1];a=r/'build-artifacts';before=json.loads((a/'pi-approved-reboot-before.json').read_text());start=time.monotonic();attempts=[]
code="import pathlib,json,os,socket;print(json.dumps({'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'uptime':pathlib.Path('/proc/uptime').read_text().strip(),'hostname':socket.gethostname(),'machine':os.uname().machine}))"
while time.monotonic()-start<45:
 try:
  p=subprocess.run(['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=3','rpi5','python3 -'],input=code.encode(),capture_output=True,timeout=6)
  row={'seconds':time.monotonic()-start,'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()};attempts.append(row)
  if p.returncode==0:
   new=json.loads(row['stdout'])
   if new['boot_id']!=before['boot_id']:
    assert new['hostname']=='RPI5' and new['machine']=='aarch64'
    report={'returned':True,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identity':new,'attempts':attempts,'reboot_command_returncode':0,'reboot_retry_count_after_new_authorization':1}
    (a/'pi-approved-reboot-return.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report));break
 except subprocess.TimeoutExpired:attempts.append({'seconds':time.monotonic()-start,'timeout':True})
 time.sleep(3)
else:
 (a/'pi-approved-reboot-return.json').write_text(json.dumps({'returned':False,'attempts':attempts},indent=2)+'\n');raise SystemExit('Pi return not yet verified; reboot will not be repeated')
